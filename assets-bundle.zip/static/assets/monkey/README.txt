Web animations adapted from user-provided ProfMonkey Desktop v0.5 source. Only sprites reused; desktop Python/permissions are not embedded into the website.
